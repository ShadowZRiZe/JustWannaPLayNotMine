import Game from './scripts/game/core';

let universegod = new Game();
universegod.init();
